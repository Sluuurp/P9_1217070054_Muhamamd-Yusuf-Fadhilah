import cv2 as cv
from matplotlib import pyplot as plt

img = cv.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/4/gura.jpeg")
edges = cv.Canny(img,100,200)
plt.subplot(121), plt.imshow(img,cmap='gray')
plt.title('Original Image'), plt.xticks([]), plt.yticks([])
plt.show

cv.imshow('Original Image', img)
cv.imshow('Canny', edges)
cv.waitKey(0)
cv.destroyAllWindows()